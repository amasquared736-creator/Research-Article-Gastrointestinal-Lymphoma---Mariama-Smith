usethis::use_git_config(
  user.name = "Mariama Smith",
  user.email = "Amasquared736@gmail.com",
)

usethis::create_github_token()
